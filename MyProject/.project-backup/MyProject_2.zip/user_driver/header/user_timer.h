﻿/*
 * user_timer.h
 *
 * Created: 2024-12-02 오후 4:27:02
 *  Author: sohaj
 */ 
extern int isReset;
void TIMER_0_enable(void);